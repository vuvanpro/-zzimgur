zzimgur
=======
Upload images use the Imgur API and HTML5

###Update
Version 1.6 (12/28/2013)


##Guide
<http://goo.gl/nExWs4>

##Demo
<https://taiimage.blogspot.com>
